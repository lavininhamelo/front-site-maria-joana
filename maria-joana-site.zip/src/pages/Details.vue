<template>
  <q-page class="row items-center justify-center">
    <h1>Em construção</h1>
  </q-page>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
