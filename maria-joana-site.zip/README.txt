Instruções para rodar o projeto:

npm install

quasar dev

npx json-server --watch db.json
